// menu
const hamburgerButton = document.querySelector('[data-hamburger-button]')
const hamburgerCloseButton = document.querySelector('[data-close-menu-button]')
const navigationUl = document.querySelector('[data-navigation-ul]')

hamburgerButton.addEventListener('click', e=> {
        if(hamburgerButton.innerHTML = "&#9776;") {
            navigationUl.classList.toggle('hidden_menu')
        }
})

hamburgerCloseButton.addEventListener('click', e=> {
    navigationUl.classList.add('hidden_menu')
})



// for animations from video

window.addEventListener('scroll', reveal)

function reveal() {
    var reveals = document.querySelectorAll('.reveal')

    for(var i = 0; i < reveals.length; i++) {
        var windowHeight = window.innerHeight
        var revealTop = reveals[i].getBoundingClientRect().top
        var revealPoint = 150

        if(revealTop < windowHeight - revealPoint) {
            reveals[i].classList.add('active')
        } else {
            reveals[i].classList.remove('active')
        }
    }
}


// about product section

const aboutSectionHeader = document.querySelector('[data-about-header]')
const about = document.querySelector('[data-about]')
const upArrow = document.querySelector('[data-up-arrow]')
const downArrow = document.querySelector('[data-down-arrow]')
const exitAbout = document.querySelector('[data-exit-about]')

aboutSectionHeader.addEventListener('click', e=> {
    about.classList.toggle('hidden_about_section')
    upArrow.classList.toggle('hidden_about')
    downArrow.classList.toggle('hidden_about')
})

exitAbout.addEventListener('click', e=> {
    about.classList.toggle('hidden_about_section')
    upArrow.classList.toggle('hidden_about')
    downArrow.classList.toggle('hidden_about')
})


